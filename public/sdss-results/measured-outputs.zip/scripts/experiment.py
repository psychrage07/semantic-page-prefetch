"""Isolated SDSS DR7 experiment using an unchanged snapshot of Pagewise."""
from __future__ import annotations
import argparse, csv, gc, hashlib, io, json, random, sqlite3, sys, time
import urllib.parse, urllib.request
from collections import defaultdict
from dataclasses import asdict, replace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'source_snapshot'))
DB = ROOT / 'data' / 'sdss-dr7.sqlite'
ENDPOINT = 'https://skyserver.sdss.org/dr7/en/tools/search/x_sql.asp'
SQL = '''SELECT TOP 50000 p.objID,p.ra,p.dec,p.u,p.g,p.r,p.i,p.z,p.type,p.run,p.rerun,p.camcol,p.field,p.extinction_r,
s.specObjID,s.z AS redshift,s.zErr,s.specClass,s.plate,s.mjd,s.fiberID
FROM SpecObj AS s JOIN PhotoObj AS p ON p.objID=s.bestObjID ORDER BY s.specObjID'''

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()

def save(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False), encoding='utf-8')

def log(message): print(message, flush=True)

def protocol():
    p=ROOT/'protocol.json'
    if p.exists(): return
    save(p, {'paper':'SeLeP: Learning Based Semantic Prefetching for Exploratory Database Workloads',
      'doi':'10.14778/3659437.3659458', 'review_2_reference':3,'review_3_reference':1,
      'paper_url':'https://www.vldb.org/pvldb/vol17/p2064-zirak.pdf',
      'authors_repository':'https://github.com/fzirak/SeLeP',
      'dataset':'Sloan Digital Sky Survey Data Release 7 (SDSS DR7)',
      'data_kind':'Real public astronomy records, bounded ordered subset; not synthetic records',
      'scope':'New SQLite workload adapted from official SDSS sample-query patterns; not original SeLeP logs, model, or PostgreSQL benchmark reproduction',
      'selection_bias':'First 50000 matched spectroscopic records ordered by specObjID; not a random or representative sample of all DR7',
      'endpoint':ENDPOINT,'download_sql':SQL,
      'workload_seeds':{'training':{'101':200,'102':200,'103':200},'validation':{'201':100,'202':100},'test':{'921':60,'922':60,'923':60,'924':60,'925':60}},
      'split':'SHA256 of template_id and complete SQL parameter tuple modulo 10: train 0-6, validation 7, test 8-9; unique combinations across executions; familiar templates, held-out combinations, not disjoint astronomical objects',
      'model':'Existing selected hybrid_semantics architecture, newly fitted to SDSS traces; original e-commerce weights are not reused',
      'config':{'variant':'b2','objective':'listwise','hidden':64,'epochs':16,'learning_rate':0.001,'weight_decay':0.0001,'prior_weight':1.0},
      'training_seed':101,'candidate_strategy':'layout','max_candidates':128,
      'training_validation_max_transitions_per_query':16,'test_transitions':'All eligible transitions, no sampling; process one query at a time to bound RAM',
      'selection':'Fixed architecture and candidate settings; validation macro Top-1 selects checkpoint epoch including explicit epoch-zero Markov fallback; no tuning from test scores',
      'controls':['Markov-1','Markov-2','sequential','history-only A (BCE)','semantic B (BCE)','hybrid without semantics'],
      'metrics':['query-average Top-1','transition-weighted Top-1','transition-weighted Top-5','candidate recall'],
      'cache':'SQLite pager 128 KiB, mmap disabled, shrink_memory between queries; OS cache is not reset',
      'runtime_smoke':'20 additional seed-501 queries from training parameter buckets; paired none/Markov-2/new neural checkpoint, no injected delay; correctness and operational check only',
      'test_policy':'All results and failures retained; candidate misses counted as errors; no model selection from test outcomes',
      'isolation':'Sibling folder outside semantic-page-prefetch, copied predictor source, distinct DB/checkpoints/outputs; existing frontend and research artifacts unchanged'})
    log('Protocol saved before data collection and fitting')

def download():
    protocol()
    path=ROOT/'data'/'sdss-dr7-specphoto.csv'
    if path.exists():
        raise FileExistsError('Preserve original download; stage already exists')
    url=ENDPOINT+'?'+urllib.parse.urlencode({'cmd':SQL,'format':'csv'})
    log('Downloading 50000 actual SDSS DR7 records in 10 keyset-paginated batches')
    start=time.monotonic();all_rows=[];batches=[];last=0;header=None
    for batch in range(10):
        sql=SQL.replace('TOP 50000','TOP 5000').replace('ORDER BY s.specObjID',f'WHERE s.specObjID>{last} ORDER BY s.specObjID')
        request_url=ENDPOINT+'?'+urllib.parse.urlencode({'cmd':sql,'format':'csv'})
        with urllib.request.urlopen(urllib.request.Request(request_url,headers={'User-Agent':'Pagewise-academic-evaluation/1.0'}),timeout=180) as response:
            raw_batch=response.read(10000000);final_url=response.url
        batch_path=ROOT/'data'/f'raw-batch-{batch+1:02d}.csv';batch_path.write_bytes(raw_batch)
        text=raw_batch.decode('utf-8-sig');reader=csv.DictReader(io.StringIO(text));rows=list(reader)
        if len(rows)!=5000 or not rows or 'specObjID' not in rows[0]:
            raise ValueError(f'Expected 5000 CSV rows, got {len(rows)}; raw response retained: {batch_path}')
        ids=[int(r['specObjID']) for r in rows]
        assert ids==sorted(ids) and len(set(ids))==len(ids) and min(ids)>last
        last=max(ids);header=reader.fieldnames;all_rows.extend(rows)
        batches.append({'request_url':request_url,'response_url':final_url,'sql':sql,'rows':len(rows),'sha256':sha(batch_path)})
        log(f'Downloaded {len(all_rows)}/50000 records')
    buffer=io.StringIO(newline='');writer=csv.DictWriter(buffer,fieldnames=header);writer.writeheader();writer.writerows(all_rows)
    raw=buffer.getvalue().encode('utf-8');rows=all_rows
    path.write_bytes(raw)
    save(ROOT/'data'/'provenance.json',{'dataset':'SDSS DR7','endpoint':ENDPOINT,'request_url':url,'response_url':final_url,
      'download_sql':SQL,'batches':batches,'download_note':'Single large response exceeded legacy ASP response buffer; same ordered subset retrieved in 5000-row keyset batches. Failed response retained in logs.','rows':len(rows),'bytes':len(raw),'sha256':sha(path),'download_seconds':time.monotonic()-start,
      'downloaded_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
      'access_and_acknowledgment':'https://classic.sdss.org/dr7/credits.html',
      'official_sample_queries':'https://skyserver.sdss.org/dr7/en/help/docs/realquery.asp',
      'paper_dataset_connection':'SeLeP section 4.1.2 uses SDSS DR7; this subset and SQLite physical layout differ from its 16GB PostgreSQL database'})
    log(f'Download complete: {len(rows)} records, {len(raw):,} bytes')

def database():
    if DB.exists(): raise FileExistsError(DB)
    rows=list(csv.DictReader((ROOT/'data'/'sdss-dr7-specphoto.csv').open(encoding='utf-8-sig',newline='')))
    con=sqlite3.connect(DB)
    con.executescript('''PRAGMA page_size=4096; PRAGMA foreign_keys=ON;
      CREATE TABLE PhotoObj(objID INTEGER PRIMARY KEY,ra REAL,dec REAL,u REAL,g REAL,r REAL,i REAL,z REAL,type INTEGER,run INTEGER,rerun INTEGER,camcol INTEGER,field INTEGER,extinction_r REAL);
      CREATE TABLE SpecObj(specObjID INTEGER PRIMARY KEY,bestObjID INTEGER REFERENCES PhotoObj(objID),redshift REAL,zErr REAL,specClass INTEGER,plate INTEGER,mjd INTEGER,fiberID INTEGER);
      CREATE INDEX photo_r ON PhotoObj(r); CREATE INDEX photo_ra_dec ON PhotoObj(ra,dec);
      CREATE INDEX photo_run_field ON PhotoObj(run,field); CREATE INDEX spec_photo ON SpecObj(bestObjID);
      CREATE INDEX spec_plate ON SpecObj(plate); CREATE INDEX spec_redshift ON SpecObj(redshift);''')
    photo={}
    for r in rows:
        values=(int(r['objID']),*[float(r[k]) for k in ['ra','dec','u','g','r','i','z']],*[int(r[k]) for k in ['type','run','rerun','camcol','field']],float(r['extinction_r']))
        if values[0] in photo: assert photo[values[0]]==values
        photo[values[0]]=values
    con.executemany('INSERT INTO PhotoObj VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',photo.values())
    con.executemany('INSERT INTO SpecObj VALUES (?,?,?,?,?,?,?,?)',[(int(r['specObjID']),int(r['objID']),float(r['redshift']),float(r['zErr']),int(r['specClass']),int(r['plate']),int(r['mjd']),int(r['fiberID'])) for r in rows])
    con.commit();con.execute('ANALYZE');con.commit()
    assert con.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    assert not con.execute('PRAGMA foreign_key_check').fetchall()
    assert con.execute('SELECT COUNT(*) FROM SpecObj JOIN PhotoObj ON objID=bestObjID').fetchone()[0]==len(rows)
    stats={'PhotoObj':len(photo),'SpecObj':len(rows),'page_size':4096,'page_count':con.execute('PRAGMA page_count').fetchone()[0]}
    con.close();stats.update(bytes=DB.stat().st_size,sha256=sha(DB))
    from pagewise.metadata import save_page_map
    save_page_map(DB,ROOT/'data'/'page_map.json')
    save(ROOT/'data'/'database.json',stats)
    log(f'Database imported and validated: {stats}')

TEMPLATES=[
 ('sdss_object','point_lookup','SELECT objID,ra,dec,u,g,r,i,z FROM PhotoObj WHERE objID=?'),
 ('sdss_magnitudes','range_scan','SELECT objID,u,g,r,i,z FROM PhotoObj WHERE r BETWEEN ? AND ? ORDER BY r,objID LIMIT ?'),
 ('sdss_sky_window','range_scan','SELECT objID,ra,dec,r,type FROM PhotoObj WHERE ra BETWEEN ? AND ? AND dec BETWEEN ? AND ? ORDER BY ra,objID LIMIT ?'),
 ('sdss_plate_join','indexed_join','SELECT s.specObjID,p.objID,p.ra,p.dec,p.r,s.redshift,s.specClass FROM SpecObj s JOIN PhotoObj p ON p.objID=s.bestObjID WHERE s.plate=? ORDER BY s.specObjID LIMIT ?'),
 ('sdss_redshift_join','indexed_join','SELECT s.specObjID,p.objID,p.u,p.g,p.r,s.redshift FROM SpecObj s JOIN PhotoObj p ON p.objID=s.bestObjID WHERE s.redshift BETWEEN ? AND ? ORDER BY s.redshift,s.specObjID LIMIT ?'),
 ('sdss_field_summary','range_scan','SELECT type,COUNT(*),AVG(r) FROM PhotoObj WHERE run=? AND field BETWEEN ? AND ? GROUP BY type ORDER BY type')]

def signature(template,params):return json.dumps([template,list(params)],separators=(',',':'))
def bucket(sig):return int(hashlib.sha256(sig.encode()).hexdigest(),16)%10

def make_cases(seed,count,split,seen=None):
    from pagewise.workloads import QueryCase
    rng=random.Random(seed);seen=seen if seen is not None else set()
    allowed={'training':set(range(7)),'validation':{7},'test':{8,9}}[split]
    con=sqlite3.connect(DB)
    anchors=con.execute('SELECT objID,ra,dec,r,run,field FROM PhotoObj ORDER BY objID').fetchall()
    plates=[x[0] for x in con.execute('SELECT DISTINCT plate FROM SpecObj ORDER BY plate')]
    reds=[x[0] for x in con.execute('SELECT redshift FROM SpecObj ORDER BY specObjID')];con.close()
    cases=[]
    for i in range(count):
        t=i%len(TEMPLATES);name,family,sql=TEMPLATES[t]
        for attempt in range(100000):
            obj,ra,dec,mag,run,field=rng.choice(anchors)
            if t==0: params=(obj,)
            elif t==1:
                width=rng.uniform(.005,.08);params=(round(mag-width,6),round(mag+width,6),rng.randint(20,100))
            elif t==2:
                width=rng.uniform(.02,.3);params=(round(ra-width,6),round(ra+width,6),round(dec-width,6),round(dec+width,6),rng.randint(20,100))
            elif t==3:params=(rng.choice(plates),rng.randint(20,100))
            elif t==4:
                z=rng.choice(reds);width=rng.uniform(.0001,.008);params=(round(z-width,7),round(z+width,7),rng.randint(20,100))
            else:params=(run,max(0,field-rng.randint(0,8)),field+rng.randint(1,8))
            sig=signature(name,params)
            if bucket(sig) in allowed and sig not in seen:break
        else:raise RuntimeError('Could not obtain unique held-out parameters')
        seen.add(sig);cases.append(QueryCase(f'{seed}-{i+1:05d}',name,family,sql,params))
    rng.shuffle(cases)
    return cases

def trace_cases(cases,out,seed,prefetch_config=None):
    from pagewise import runner
    from pagewise.dataset import build_sequences
    old=runner.generate_workload
    runner.generate_workload=lambda *a,**k:cases
    try:result=runner.trace_workload(DB,out,query_count=len(cases),seed=seed,cache_kib=128,prefetch_config=prefetch_config)
    finally:runner.generate_workload=old
    seqs=build_sequences(out/'trace.jsonl',out/'page_map.json',out/'sequences.jsonl')
    lookup={c.query_id:c for c in cases}
    for s in seqs:s.update(params=list(lookup[s['query_id']].params),workload_seed=seed)
    (out/'sequences.jsonl').write_text(''.join(json.dumps(s)+'\n' for s in seqs),encoding='utf-8')
    return seqs,result

def collect():
    protocol();p=json.loads((ROOT/'protocol.json').read_text());seen=set();split_ids={};all_cases={};all_seqs={}
    for split,seeds in p['workload_seeds'].items():
        split_ids[split]=[];all_cases[split]=[];all_seqs[split]=[]
        for seed,count in seeds.items():
            out=ROOT/'traces'/f'{split}-{seed}'
            if out.exists():raise FileExistsError(out)
            cases=make_cases(int(seed),count,split,seen);seqs,_=trace_cases(cases,out,int(seed))
            split_ids[split].extend(c.query_id for c in cases)
            all_cases[split].extend(c.serializable() for c in cases);all_seqs[split].extend(seqs)
            log(f'Traced {split}/{seed}: {len(cases)} SQL queries, {sum(max(0,len(s["pages"])-1) for s in seqs)} transitions')
        for name,rows in [('workload',all_cases[split]),('sequences',all_seqs[split])]:
            (ROOT/'traces'/f'{split}-{name}.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows),encoding='utf-8')
    save(ROOT/'traces'/'partition.json',split_ids)

def load_split(split):
    from pagewise.dataset import load_jsonl
    return load_jsonl(ROOT/'traces'/f'{split}-sequences.jsonl'),{c['query_id']:c for c in load_jsonl(ROOT/'traces'/f'{split}-workload.jsonl')}

def train():
    import numpy as np,torch
    from pagewise.models import CandidateIndex,page_map_digest
    from pagewise import ml_variants as ML
    from pagewise.ranking import RankerConfig,build_groups,train_ranker,evaluate_ranker,fit_parameter_scales,fit_temperature
    torch.set_num_threads(1)
    training,cases=load_split('training');validation,vcases=load_split('validation');cases.update(vcases)
    metadata=json.loads((ROOT/'data'/'page_map.json').read_text())
    index=CandidateIndex.build(training,128,strategy='layout',page_map=metadata,layout_database_path=str(DB))
    index.page_map_sha256=page_map_digest(metadata)
    save(ROOT/'models'/'candidate_index.json',index.to_json());save(ROOT/'models'/'page_map.json',metadata)
    counts=ML.build_training_transition_counts(training,max_candidates=128);scales=fit_parameter_scales(training,cases)
    configs=[RankerConfig('hybrid_semantics',epochs=16,prior_weight=1.0),RankerConfig('hybrid_no_semantics',epochs=16,prior_weight=1.0,no_semantics=True),RankerConfig('model_b',variant='b',objective='bce',epochs=16),RankerConfig('model_a',variant='a',objective='bce',epochs=16)]
    declaration={'protocol_sha256':sha(ROOT/'protocol.json'),'database_sha256':sha(DB),'training_trace_sha256':sha(ROOT/'traces'/'training-sequences.jsonl'),'validation_trace_sha256':sha(ROOT/'traces'/'validation-sequences.jsonl'),'test_not_evaluated':True,'models':{}}
    for config in configs:
        path=ROOT/'models'/f'{config.name}.pt'
        if path.exists():raise FileExistsError(path)
        log(f'Training {config.name}, fixed architecture, up to 16 epochs')
        start=time.monotonic()
        tr=build_groups(training,index,metadata,counts,config,cases,scales,max_per_query=16)
        va=build_groups(validation,index,metadata,counts,config,cases,scales,max_per_query=16)
        model,fit=train_ranker(tr,va,config,seed=101)
        metrics=evaluate_ranker(model,va,config);calibration=fit_temperature(model,va,config)
        payload={'config':asdict(config),'state_dict':model.state_dict(),'input_dim':tr['x'].shape[-1],'normalization_max_page':index.max_page,'counts':counts,'parameter_scales':scales,'fit':fit,'calibration':calibration}
        torch.save(payload,path)
        declaration['models'][config.name]={'checkpoint':path.name,'sha256':sha(path),'config':asdict(config),'fit':fit,'validation':metrics,'calibration':calibration,'elapsed_seconds':time.monotonic()-start,'trained_neural_component':fit['best_epoch']>0}
        save(ROOT/'models'/'freeze.json',declaration)
        log(f'DONE {config.name}: validation macro Top1={metrics["top1_macro_pct"]:.3f}%, selected epoch={fit["best_epoch"]}')
        del tr,va,model;gc.collect()
    save(ROOT/'models'/'freeze-complete.json',{'freeze_sha256':sha(ROOT/'models'/'freeze.json'),'candidate_index_sha256':sha(ROOT/'models'/'candidate_index.json'),'page_map_sha256':sha(ROOT/'models'/'page_map.json')})

def evaluate():
    import numpy as np,torch
    from pagewise.models import CandidateIndex
    from pagewise.ranking import NeuralPredictor,build_groups,evaluate_ranker,logits
    torch.set_num_threads(1)
    marker=json.loads((ROOT/'models'/'freeze-complete.json').read_text())
    assert marker['freeze_sha256']==sha(ROOT/'models'/'freeze.json')
    freeze=json.loads((ROOT/'models'/'freeze.json').read_text())
    index=CandidateIndex.from_json(json.loads((ROOT/'models'/'candidate_index.json').read_text()))
    metadata=json.loads((ROOT/'models'/'page_map.json').read_text())
    predictors={name:NeuralPredictor(ROOT/'models'/spec['checkpoint'],index,metadata) for name,spec in freeze['models'].items()}
    for name,spec in freeze['models'].items():assert sha(ROOT/'models'/spec['checkpoint'])==spec['sha256']
    seqs,cases=load_split('test');rows=[]
    samples=(ROOT/'results'/'prediction-samples.jsonl').open('w',encoding='utf-8')
    for k,seq in enumerate(seqs):
        p=predictors['hybrid_semantics']
        base=build_groups([seq],index,metadata,p.counts,p.config,cases,p.parameter_scales,max_per_query=None)
        n=len(base['target']);truth=base['target_page']
        for name,p in predictors.items():
            data=base if name=='hybrid_semantics' else build_groups([seq],index,metadata,p.counts,p.config,cases,p.parameter_scales,max_per_query=None)
            m=evaluate_ranker(p.model,data,p.config)
            rows.append({'policy':name,'query_id':seq['query_id'],'seed':seq['workload_seed'],'template_id':seq['template_id'],'transitions':n,'top1_hits':round(m['top1_micro_pct']*n/100),'top5_hits':round(m['top5_micro_pct']*n/100),'candidate_hits':int((data['target']>=0).sum()),'top1_pct':m['top1_macro_pct']})
            if name!='hybrid_semantics':del data
        for name,a in [('markov1',base['markov1_top5']),('markov2',base['markov2_top5']),('sequential',(np.asarray(seq['pages'][:-1])+1)[:,None])]:
            h1=int((a[:,0]==truth).sum());h5=int((a==truth[:,None]).any(1).sum())
            rows.append({'policy':name,'query_id':seq['query_id'],'seed':seq['workload_seed'],'template_id':seq['template_id'],'transitions':n,'top1_hits':h1,'top5_hits':h5,'candidate_hits':None,'top1_pct':100*h1/n})
        p=predictors['hybrid_semantics']
        for i in range(1,min(len(seq['pages']),4)):
            history=seq['pages'][max(0,i-8):i];context={**cases[seq['query_id']],'workload_family':seq['workload_family'],'plan_class':seq['plan_class'],'position_in_query':min(i,512)/512}
            ranked=p.rank(history,context)
            x=torch.from_numpy(base['x'][i-1:i]);prior=torch.from_numpy(base['prior'][i-1:i]);valid=torch.from_numpy(base['pages'][i-1:i]!=-1)
            with torch.inference_mode():expected=int(base['pages'][i-1,torch.argmax(logits(p.model,x,prior,valid,p.config)).item()])
            assert ranked[0][0]==expected,'Offline/runtime prediction feature or ranking mismatch'
            samples.write(json.dumps({'query_id':seq['query_id'],'history':history,'actual_next_page':seq['pages'][i],'top5':ranked[:5]})+'\n')
        del base;gc.collect()
        if (k+1)%30==0:log(f'Full held-out evaluation {k+1}/{len(seqs)} queries')
    samples.close()
    with (ROOT/'results'/'per-query.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    summary={}
    for name in sorted(set(r['policy'] for r in rows)):
        rs=[r for r in rows if r['policy']==name];n=sum(r['transitions'] for r in rs)
        summary[name]={'queries':len(rs),'transitions':n,'top1_macro_pct':float(np.mean([r['top1_pct'] for r in rs])),'top1_micro_pct':100*sum(r['top1_hits'] for r in rs)/n,'top5_micro_pct':100*sum(r['top5_hits'] for r in rs)/n,'candidate_recall_pct':100*sum(r['candidate_hits'] for r in rs)/n if rs[0]['candidate_hits'] is not None else None,'by_template':{t:float(np.mean([r['top1_pct'] for r in rs if r['template_id']==t])) for t in sorted(set(r['template_id'] for r in rs))}}
    own={r['query_id']:r['top1_pct'] for r in rows if r['policy']=='hybrid_semantics'}
    other={r['query_id']:r['top1_pct'] for r in rows if r['policy']=='markov2'}
    rng=np.random.default_rng(617);byseed={s:[r['query_id'] for r in rows if r['policy']=='hybrid_semantics' and r['seed']==s] for s in sorted(set(r['seed'] for r in rows))}
    diffs=[];seeds=list(byseed)
    for _ in range(5000):
        vals=[]
        for s in rng.choice(seeds,len(seeds),replace=True):
            ids=byseed[int(s)];vals.extend(own[q]-other[q] for q in rng.choice(ids,len(ids),replace=True))
        diffs.append(np.mean(vals))
    report={'scope':'Separate SDSS DR7 subset, familiar SQLite templates, held-out SQL parameter combinations; not a SeLeP reproduction or runtime speedup claim','sampled':False,'freeze_sha256':sha(ROOT/'models'/'freeze.json'),'policies':summary,'hybrid_minus_markov2_macro_pp':summary['hybrid_semantics']['top1_macro_pct']-summary['markov2']['top1_macro_pct'],'descriptive_seed_and_query_bootstrap_95_ci_pp':[float(x) for x in np.percentile(diffs,[2.5,97.5])],'bootstrap_replicates':5000}
    save(ROOT/'results'/'accuracy.json',report)
    with (ROOT/'results'/'accuracy.csv').open('w',newline='',encoding='utf-8') as f:
        fields=['policy','queries','transitions','top1_macro_pct','top1_micro_pct','top5_micro_pct','candidate_recall_pct'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for name,r in summary.items():w.writerow({'policy':name,**{k:r[k] for k in fields[1:]}})
    log(json.dumps(report,indent=2))

def runtime():
    from pagewise.dataset import load_jsonl
    freeze=json.loads((ROOT/'models'/'freeze.json').read_text());configs=[]
    cases=make_cases(501,20,'training')
    policies=['none','markov2','model_ranker'];random.Random(501).shuffle(policies)
    results={};fingerprints={}
    for policy in policies:
        cfg={'strategy':policy,'candidate_index_path':str(ROOT/'models'/'candidate_index.json'),'model_path':str(ROOT/'models'/'hybrid_semantics.pt') if policy=='model_ranker' else None,'semantic':True,'cache_pages':512,'prefetch_workers':1,'degree':1,'confidence_threshold':.7,'queue_size':64,'predict_on':'miss','predict_every':4,'drop_stale_jobs':True,'miss_delay_ms':0,'diagnostics_enabled':True}
        out=ROOT/'results'/'runtime'/policy
        if out.exists():raise FileExistsError(out)
        trace_cases(cases,out,501,cfg)
        stats=json.loads((out/'runtime_stats.json').read_text());assert stats['worker_shutdown_clean'] and stats['worker_idle_before_close']
        results[policy]={'metadata':json.loads((out/'run_metadata.json').read_text()),'runtime_stats':stats}
        q=list(csv.DictReader((out/'query_results.csv').open()))
        fingerprints[policy]=[(r['query_id'],r['result_rows'],r['first_rows_preview']) for r in results[policy]['metadata']['results']]
        log(f'Runtime smoke complete: {policy}')
    assert all(v==next(iter(fingerprints.values())) for v in fingerprints.values())
    save(ROOT/'results'/'runtime-smoke.json',{'policy_order':policies,'scope':'Operational smoke check, 20 paired fresh queries, no injected delay, OS cache not reset; not a speedup study','results':results})

def verify():
    repo=ROOT.parent.parent/'semantic-page-prefetch';before=json.loads((ROOT/'original-project-before.json').read_text());changed=[]
    for rel,expected in before.items():
        p=repo/rel
        if isinstance(expected,dict):
            actual={'size':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns,'header_sha256':hashlib.sha256(p.open('rb').read(100)).hexdigest()}
        else:actual=sha(p)
        if actual!=expected:changed.append(rel)
    assert not changed,f'Original files changed: {changed}'
    source=json.loads((ROOT/'source_snapshot'/'ORIGIN.json').read_text())
    assert all(sha(ROOT/'source_snapshot'/p)==v for p,v in source['source_sha256'].items())
    assert sha(DB)==json.loads((ROOT/'data'/'database.json').read_text())['sha256']
    splits={s:load_split(s) for s in ['training','validation','test']}
    sigs={s:{signature(c['template_id'],c['params']) for c in cases.values()} for s,(_,cases) in splits.items()}
    assert not sigs['training']&sigs['validation'] and not sigs['training']&sigs['test'] and not sigs['validation']&sigs['test']
    for s,(_,cases) in splits.items():
        allowed={'training':set(range(7)),'validation':{7},'test':{8,9}}[s]
        assert all(bucket(signature(c['template_id'],c['params'])) in allowed for c in cases.values())
    rows=list(csv.DictReader((ROOT/'results'/'per-query.csv').open()));groups=defaultdict(set)
    for r in rows:groups[r['query_id']].add(int(r['transitions']));assert int(r['top1_hits'])<=int(r['top5_hits'])<=int(r['transitions'])
    assert all(len(x)==1 for x in groups.values())
    expected={s['query_id']:len(s['pages'])-1 for s in splits['test'][0] if len(s['pages'])>1}
    assert {q:next(iter(v)) for q,v in groups.items()}==expected
    freeze=json.loads((ROOT/'models'/'freeze.json').read_text())
    assert all(sha(ROOT/'models'/v['checkpoint'])==v['sha256'] for v in freeze['models'].values())
    from pagewise.models import CandidateIndex
    index=json.loads((ROOT/'models'/'candidate_index.json').read_text())
    rebuilt=CandidateIndex.build(splits['training'][0],128,strategy='layout',layout_database_path=str(DB)).to_json()
    assert all(rebuilt[k]==index[k] for k in ['successors','second_order','popular','max_page','max_candidates','strategy'])
    save(ROOT/'results'/'verification.json',{'passed':True,'original_project_files_checked':len(before),'original_project_unchanged':True,'source_snapshot_unchanged':True,'database_full_sha256_unchanged':True,'sql_parameter_splits_disjoint':True,'all_test_transitions_scored':True,'same_targets_for_all_policies':True,'candidate_index_rebuilt_from_training_only':True,'offline_runtime_rank_parity_checked':True,'frozen_checkpoint_hashes_match':True,'query_counts':{s:len(x[1]) for s,x in splits.items()}})
    log('Verification passed: original project unchanged, split isolation, full-transition scoring, source and checkpoint hashes')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['protocol','download','database','collect','train','evaluate','runtime','verify']);args=parser.parse_args()
    globals()[args.stage]()

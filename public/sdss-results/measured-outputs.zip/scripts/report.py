"""Independent result audit and readable report; never fits or changes a model."""
import csv,hashlib,json,math,sys
from collections import defaultdict
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def read(path):return json.loads((ROOT/path).read_text(encoding='utf-8'))
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()

accuracy=read('results/accuracy.json');verify=read('results/verification.json');freeze=read('models/freeze.json');seal=read('models/evaluation-seal.json');runtime=read('results/runtime-smoke.json');db=read('data/database.json')
assert verify['passed'] and verify['original_project_unchanged']
assert sha(ROOT/'scripts'/'experiment.py')==seal['experiment_script_sha256']==sha(ROOT/'scripts'/'frozen-experiment.py')
assert sha(ROOT/'models'/'freeze.json')==seal['freeze_sha256']==accuracy['freeze_sha256']
rows=list(csv.DictReader((ROOT/'results'/'per-query.csv').open()))
qpolicies=defaultdict(set)
for r in rows:qpolicies[r['query_id']].add(r['policy'])
expected=set(accuracy['policies'])
assert len(qpolicies)==300 and all(v==expected for v in qpolicies.values())
assert len(rows)==300*len(expected)
for name,m in accuracy['policies'].items():
    rs=[r for r in rows if r['policy']==name];n=sum(int(r['transitions']) for r in rs)
    assert n==m['transitions']==12639
    assert math.isclose(m['top1_micro_pct'],100*sum(int(r['top1_hits']) for r in rs)/n,abs_tol=1e-10)
    assert math.isclose(m['top5_micro_pct'],100*sum(int(r['top5_hits']) for r in rs)/n,abs_tol=1e-10)
    assert math.isclose(m['top1_macro_pct'],sum(float(r['top1_pct']) for r in rs)/len(rs),abs_tol=1e-10)
    if m['candidate_recall_pct'] is not None:assert m['top5_micro_pct']<=m['candidate_recall_pct']+1e-10
assert all(v['runtime_stats']['worker_shutdown_clean'] and v['runtime_stats']['prefetch_read_errors']==0 for v in runtime['results'].values())
sys.path.insert(0,str(ROOT/'source_snapshot'))
from pagewise import ml_variants as ML
from pagewise.dataset import load_jsonl
import torch
counts=ML.build_training_transition_counts(load_jsonl(ROOT/'traces'/'training-sequences.jsonl'),max_candidates=128)
for spec in freeze['models'].values():
    payload=torch.load(ROOT/'models'/spec['checkpoint'],weights_only=True,map_location='cpu')
    assert payload['counts']==counts,'Checkpoint counts differ from training-only reconstruction'
labels={'hybrid_semantics':'Our neural hybrid (semantics + Markov)','hybrid_no_semantics':'Hybrid without semantics','model_a':'History-only Model A','model_b':'Semantic Model B','markov1':'Markov-1','markov2':'Markov-2','sequential':'Sequential'}
order=['hybrid_semantics','markov2','markov1','hybrid_no_semantics','model_b','model_a','sequential']
table=['| Predictor | Query-average Top-1 | Transition Top-1 | Transition Top-5 |','|---|---:|---:|---:|']
for name in order:
    m=accuracy['policies'][name];table.append(f'| {labels[name]} | {m["top1_macro_pct"]:.2f}% | {m["top1_micro_pct"]:.2f}% | {m["top5_micro_pct"]:.2f}% |')
delta=accuracy['hybrid_minus_markov2_macro_pp'];ci=accuracy['descriptive_seed_and_query_bootstrap_95_ci_pp'];own=accuracy['policies']['hybrid_semantics']
hist=['| Model | Validation-selected epoch | Validation macro Top-1 |','|---|---:|---:|']
for name,spec in freeze['models'].items():hist.append(f'| {labels[name]} | {spec["fit"]["best_epoch"]} | {spec["validation"]["top1_macro_pct"]:.2f}% |')
family=['| Query template | Hybrid macro Top-1 | Markov-2 macro Top-1 |','|---|---:|---:|']
for template,v in own['by_template'].items():family.append(f'| {template} | {v:.2f}% | {accuracy["policies"]["markov2"]["by_template"][template]:.2f}% |')
timing=['| Policy | Mean foreground query ms | Median query ms | Prefetched pages | Useful prefetches | Scored jobs | Read errors |','|---|---:|---:|---:|---:|---:|---:|']
for name in runtime['policy_order']:
    r=runtime['results'][name];meta=r['metadata'];stats=r['runtime_stats'];lat=[x['elapsed_ms'] for x in meta['results']]
    timing.append(f'| {"Our neural hybrid" if name=="model_ranker" else name} | {sum(lat)/len(lat):.3f} | {meta["query_latency_ms"]["median"]:.3f} | {stats.get("pages_prefetched",0)} | {stats.get("useful_prefetches",0)} | {stats.get("prediction_jobs_scored",stats.get("jobs_scored","n/a"))} | {stats["prefetch_read_errors"]} |')
report=f'''# Pagewise on a separate SDSS DR7 dataset

Completed local experiment, 27 October 2026. Original project and saved results are unchanged.

## What was run

The dataset is real astronomy data from [SDSS Data Release 7](https://classic.sdss.org/dr7/), used in [SeLeP, PVLDB 2024](https://www.vldb.org/pvldb/vol17/p2064-zirak.pdf). SeLeP appears in both project reviews: Review 2 reference 3 and Review 3 reference 1.

We downloaded 50,000 matched photometry/spectrum records, imported 49,999 distinct PhotoObj rows and 50,000 SpecObj rows, and built a separate {db['bytes']:,}-byte SQLite database ({db['page_count']:,} pages). These are actual survey measurements. This is the first 50,000 matching spectra ordered by ID, not a random or representative sample.

The SQL workload is newly generated from six templates adapted from the [official SDSS sample queries](https://skyserver.sdss.org/dr7/en/help/docs/realquery.asp). It is not SeLeP's original workload. Pagewise traces actual SQLite reads with APSW. SeLeP used a different PostgreSQL database, model, layout, task, and metrics; its published hit ratios cannot be compared directly with these next-page accuracies.

The same selected neural-hybrid architecture was trained from new weights on this dataset. No original checkpoint was overwritten or reused. New models, traces, data, and outputs live entirely in this sibling experiment directory.

## Held-out results

Training: 600 queries / 25,445 observed transitions. Validation: 200 queries / 8,088 observed transitions. Test: 300 queries / 12,639 observed transitions, across five workload seeds. Training and validation sample at most 16 transitions per query; the table below scores all 12,639 test transitions without sampling.

{chr(10).join(table)}

Our hybrid minus Markov-2 in query-average Top-1: **{delta:+.2f} percentage points**. The descriptive hierarchical bootstrap 95% interval is [{ci[0]:+.2f}, {ci[1]:+.2f}] points (5,000 resamples of workload seeds and queries). This is a descriptive comparison for this bounded dataset and workload, not a claim of general superiority.

Hybrid candidate recall: **{own['candidate_recall_pct']:.2f}%**. Targets absent from the candidate pool remain incorrect. Macro gives every query equal weight; micro gives every transition equal weight. Report both because long join queries otherwise dominate.

## Training details

Fixed selected architecture: B2 features, hidden width 64, listwise loss, Markov log-prior weight 1, AdamW learning rate 0.001, up to 16 epochs, training seed 101. Candidate generation: existing layout-aware generator, maximum 128 candidates. Checkpoint epoch is chosen on validation macro Top-1 only. All model configurations were fixed before test scoring.

{chr(10).join(hist)}

All four selected checkpoints have a learned neural component (selected epoch above zero). The no-semantics control disables semantic features while retaining history and Markov features. Candidate proposal and transition statistics use training executions only. Full static B-tree metadata is allowed from the read-only database and is not filtered by future test membership.

The exact experiment script and all checkpoint hashes were sealed before scoring the held-out test. See `models/evaluation-seal.json`, `models/freeze.json`, and `scripts/frozen-experiment.py`.

## Results by query template

{chr(10).join(family)}

## Actual runtime smoke check

Twenty additional paired queries per policy ran through the existing APSW tracing and asynchronous prefetch runtime, using the newly fitted checkpoint. All workers shut down cleanly with zero prefetch read errors. The check compares result row counts and first-row previews across policies; it is not a full result-stream checksum check.

{chr(10).join(timing)}

Policy order was randomized once with seed 501 and recorded. SQLite pager cache was 128 KiB; the Pagewise cache was 512 pages, with one worker, degree 1, confidence threshold 0.7, prediction on every fourth miss, stale-job dropping, and no artificial delay. The OS cache was not reset. This small smoke check establishes operational completion and preserves timing diagnostics; it does not establish a statistically supported speedup.

## Checks and limits

- Actual database integrity and foreign-key checks passed; exported IDs retain exact integer precision.
- SQL template/parameter combinations do not overlap between training, validation, and test. Templates and some data pages do overlap. This is not an unseen-template or unseen-object test.
- All predictors were scored on identical held-out transitions; every eligible test transition is included.
- Accuracy aggregates were independently recomputed from per-query hit counts.
- Candidate index and checkpoint transition counts were rebuilt from training only and matched saved artifacts.
- Offline and runtime predictor rankings matched on recorded samples.
- Source snapshot and frozen checkpoint hashes match; separate SQLite database full SHA256 remains unchanged.
- {verify['original_project_files_checked']} protected original paths passed before/after checks. Tracked files and original checkpoint are hashed fully; the original 8.62 GB database is checked by size, modification time, and header hash, not a full-file hash.
- This is one bounded ordered SDSS subset, one SQLite layout, one host, and generated SQL parameters. It is a separate external-data experiment, not a replacement for the existing research study.

## Where to inspect outputs

- `data/provenance.json`: exact service requests, SQL, raw batch hashes, and dataset origin.
- `data/sdss-dr7.sqlite`: the real, separately imported database.
- `models/hybrid_semantics.pt`: the newly fitted neural hybrid.
- `models/freeze.json`: training histories, validation selection, configurations, and checkpoint hashes.
- `results/accuracy.csv` / `accuracy.json`: full comparison, including controls.
- `results/per-query.csv`: every query/policy's hit counts.
- `results/prediction-samples.jsonl`: actual next-page predictions and targets.
- `traces/`: actual VFS reads and SQL execution records.
- `results/runtime/`: real runtime traces, predictions, timings, and counters.
- `results/verification.json` and `results/independent-audit.json`: verification evidence.

See `README.md` for reproduction commands and [SDSS acknowledgements](https://classic.sdss.org/dr7/credits.html) for data attribution.
'''
(ROOT/'RESULTS.md').write_text(report,encoding='utf-8')
(ROOT/'results'/'independent-audit.json').write_text(json.dumps({'passed':True,'policies_per_query':len(expected),'test_queries':300,'transitions_per_policy':12639,'aggregate_scores_recomputed':True,'training_only_checkpoint_counts_rebuilt':True,'sealed_experiment_script_unchanged':True,'all_models_selected_trained_epoch':all(v['fit']['best_epoch']>0 for v in freeze['models'].values()),'runtime_prefetch_read_errors':0,'runtime_workers_clean':True},indent=2))
print('Independent audit passed; wrote RESULTS.md')
print('\n'.join(table))

# Separate Pagewise experiment: SDSS DR7

This directory is independent of `semantic-page-prefetch`. It contains its own downloaded data, SQLite database, copied backend source, trained model weights, traces, logs, and measured results. Nothing here is connected to the existing frontend or included in its scores.

## Dataset and paper

SeLeP is reference 3 in `material/Pagewise_Review_2_Journal_References.docx` and reference 1 in `standard format/Pagewise_Review_3_IEEE.docx`.

- Paper: [SeLeP, PVLDB 17(8), 2024](https://www.vldb.org/pvldb/vol17/p2064-zirak.pdf), DOI `10.14778/3659437.3659458`.
- Authors' artifact: https://github.com/fzirak/SeLeP
- Dataset: actual [Sloan Digital Sky Survey Data Release 7](https://classic.sdss.org/dr7/) records from the official SkyServer SQL service.
- Query patterns: https://skyserver.sdss.org/dr7/en/help/docs/realquery.asp
- Data acknowledgement: https://classic.sdss.org/dr7/credits.html

The downloaded subset contains the first 50,000 matched spectrum/photometry records ordered by spectrum ID. It is a bounded, non-random subset. Importing it gives 49,999 distinct photometric objects and 50,000 spectra in two related SQLite tables. One object has more than one matched spectrum; the original relationship is preserved. The database has 3,855 pages of 4,096 bytes, totaling 15,790,080 bytes. IDs are imported as exact integers, without floating-point conversion.

The astronomical measurements are real. The 1,100 local SQL executions are generated from six query templates adapted to these tables. These are not SeLeP's original user query logs. SQLite has a new physical page layout, so page numbers and traces are collected anew with APSW. This is an evaluation of Pagewise on a paper-linked dataset, not a reproduction of SeLeP or a comparison against its published scores.

## Training and evaluation

The neural hybrid uses the project's selected `hybrid_semantics` architecture: B2 semantic/history/Markov features, a 64-unit hidden layer, listwise loss, and a Markov log-prior with weight 1. It starts with new weights and is fitted on this database's training traces. Existing e-commerce checkpoints are not used.

Fixed settings are recorded before fitting in `protocol.json`. Training uses 600 queries, validation uses 200, and testing uses 300 across five new workload seeds. Whole SQL parameter combinations are assigned to disjoint partitions with SHA256 buckets. Familiar query templates appear in every partition. This does not hold out entire astronomical objects or query templates, and overlapping ranges can access some of the same records and pages.

Candidate counts and Markov probabilities use training traces only. Static B-tree metadata comes from the complete read-only SQLite snapshot. Training and validation use at most 16 transitions per query to bound memory. Every eligible test transition is scored without sampling. Missing candidates count as errors.

There is no hyperparameter search on test data. Validation query-average Top-1 selects the best epoch, up to 16. A hybrid checkpoint at epoch zero must be described as a Markov fallback with no learned residual, if selected. History-only Model A, semantic Model B, and a hybrid with semantics disabled are fitted as separate controls. Native Markov-1, Markov-2, and sequential policies are evaluated on the same targets.

Top-1 means the first prediction matches the next actual page. Top-5 means the next page appears among the first five predictions. Macro Top-1 gives each query equal weight. Micro Top-1 and Top-5 give each transition equal weight. Candidate recall measures whether the actual next page was proposed at all. The descriptive bootstrap interval resamples workload seeds and queries; this single-host subset study does not establish broad generalization.

The runtime smoke test executes 20 additional paired queries per policy with no artificial delay. It checks that the checkpoint runs in the actual prefetch worker, captures diagnostics, and shuts down cleanly. It is not a latency study. VFS reads can be served by the operating-system cache and are not proof of physical disk reads.

## Files

- `data/provenance.json`: download SQL, URLs, source details, batch hashes.
- `data/raw-batch-*.csv`: original service responses.
- `data/sdss-dr7-specphoto.csv`: combined real records.
- `data/sdss-dr7.sqlite`: separate SQLite database.
- `source_snapshot/`: unchanged copy of Pagewise predictor and tracing source.
- `traces/`: actual APSW xRead traces, workloads, and page sequences.
- `models/`: new checkpoints, training history, validation results, and freeze hashes.
- `results/accuracy.json` and `accuracy.csv`: held-out measurements.
- `results/per-query.csv`: scores and hit counts for each query and policy.
- `results/prediction-samples.jsonl`: next-page predictions and actual targets.
- `results/runtime/`: actual worker predictions, VFS traces, timings, and counters.
- `results/verification.json`: split, scoring, artifact, and isolation checks.
- `RESULTS.md`: generated measured report after the run completes.
- `logs/`: real stage output, including the initial failed large-download response.

## Reproduction

The run uses the existing Python environment for installed dependencies, but imports only `source_snapshot/pagewise`. This does not install or modify dependencies in that environment. From this directory:

```powershell
$python = 'D:\shortly-source\OS Project\semantic-page-prefetch\backend\.venv\Scripts\python.exe'
& $python scripts\experiment.py download
& $python scripts\experiment.py database
& $python scripts\experiment.py collect
& $python scripts\experiment.py train
& $python scripts\experiment.py evaluate
& $python scripts\experiment.py runtime
& $python scripts\experiment.py verify
```

Stages that create expensive artifacts refuse to overwrite existing outputs. To repeat the whole experiment, copy the script and source snapshot into a new sibling experiment directory and run there. Preserve `protocol.json` and source provenance. The original project's before/after protection check is specific to this folder location and starting checkout.
